# Chat-App
Chat app made using sockets in tkinter module in python

First Screen
![chat_1](https://user-images.githubusercontent.com/84488726/120884952-d5da7f00-c603-11eb-88de-b9a8b8448635.png)

Chat Screen
![chat_2](https://user-images.githubusercontent.com/84488726/120884960-e4c13180-c603-11eb-9fb6-343055e7d637.png)

